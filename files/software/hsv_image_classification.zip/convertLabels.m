function [ numericalLabels ] = convertLabels( stringLabels )

uLabels = unique(stringLabels);
numericalLabels = zeros(length(stringLabels),1);

for i=1:length(uLabels)
    numericalLabels = numericalLabels + i*strcmp(stringLabels,uLabels(i));
end

end

