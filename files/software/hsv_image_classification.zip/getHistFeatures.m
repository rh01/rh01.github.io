function [ featureMatrix labels ] = getHistFeatures( directoryName, nBins, type )
%for more information: www.isikdogan.com

files = dir(fullfile(directoryName,'*.jpg'));
labels = cell(length(files),1);

%initialize the feature matrix
if(strcmp(type,'HSV'))
    featureMatrix = zeros(length(files),nBins*3);
elseif(strcmp(type,'HSV5'))
    featureMatrix = zeros(length(files),nBins*3*5);
end

for i=1:length(files)
    img = imread(fullfile(directoryName,files(i).name));
    
    if (size(img, 3) ~= 3)
        disp('Image should be colored.');
        continue;
    end

    hsv_img = rgb2hsv(img);
    
    %parse labels from filenames
    labels{i} = strtok(files(i).name,'-');
    
    %generate histograms for each channel
    hHist = imhist(hsv_img(:,:,1), nBins);
    sHist = imhist(hsv_img(:,:,2), nBins);
    vHist = imhist(hsv_img(:,:,3), nBins);
    
    %create normalized feature vector
    features = [(hHist')./sum(hHist),(sHist')./sum(sHist),(vHist')./sum(vHist)];
    
    if(strcmp(type,'HSV5'))
        [m n c] = size(hsv_img);
        
        %split images and add features
        for j=1:2
            for k=1:2
                splitImg = hsv_img(floor((j-1)*(m/2)+1):floor(j*m/2), floor((k-1)*(n/2)+1):floor(k*n/2),:);
                hHist = imhist(splitImg(:,:,1), nBins);
                sHist = imhist(splitImg(:,:,2), nBins);
                vHist = imhist(splitImg(:,:,3), nBins);
                %append normalized features to the vector
                idx = (j-1)*2 + k;
                features(:,idx*(nBins*3)+1:(idx+1)*(nBins*3)) = [(hHist')./sum(hHist),(sHist')./sum(sHist),(vHist')./sum(vHist)];
            end
        end
        
    end

    featureMatrix(i,:) = features; 
end


end

