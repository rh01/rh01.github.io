%www.isikdogan.com

nBins = 8;
type = 'HSV5';

%% Get train set
dname = uigetdir('Select Training Image Folder');

if( dname == 0 )
    return;
end

[trainSet trainLabels] = getHistFeatures(dname, nBins, type);

%% Get test set
dname = uigetdir('Select Test Image Folder');

if( dname == 0 )
    return;
end

[testSet testLabels] = getHistFeatures(dname, nBins, type);

%classify with knn just for comparison
%classes = knnclassify(testSet,trainSet,trainLabels,3);
%classperf(testLabels,classes)

%convert label names into numerical variables
trainLabelsN = convertLabels(trainLabels);
testLabelsN = convertLabels(testLabels);

%% Evaluation
%5-fold cross validation on the training set in order to determine C
C = '-c 128';
indices = crossvalind('Kfold',trainLabelsN,5);
overall_perf = 0;
for i = 1:5
    test = (indices == i); train = ~test;
    model = svmtrain(trainLabelsN(train,:), trainSet(train,:), C);
    [predict_label, accuracy, dec_values] = svmpredict(trainLabelsN(test,:), trainSet(test,:), model);
    overall_perf = overall_perf + accuracy(1);
end
overall_perf = overall_perf/5;

%Overall training error
model = svmtrain(trainLabelsN, trainSet, C);
[predict_label, accuracy, dec_values] = svmpredict(trainLabelsN, trainSet, model);
trainingError = 100-accuracy(1);

%Overall performance on the test set
model = svmtrain(trainLabelsN, trainSet, C);
[predict_label, accuracy, dec_values] = svmpredict(testLabelsN, testSet, model);
performance = accuracy(1);

%Confusion matrix
cp = classperf(predict_label,testLabelsN);
confusionM = cp.CountingMatrix;